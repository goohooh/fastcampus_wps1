## front 설명<br/>
front-end 사전과제<br/>
<br/>
설 연휴 기간동안 front-end 첫 수업을 위한 사전과제<br/>
html5와 css3의 이해도 측정을 위한 과제<br/>
후에 제일 위 페이지에 jquery까지 넣는것이 목적<br/>

###학습목표
1. css 예습<br/>
2. html 마스터<br/>
3. jquery와 javascript 기본적인 개념의 이해<br/>

###사용방법
1. 업데이트 사항을 깃에 push한다<br/>
2. 서버에서 sh front.sh로 쉘을 실행시킨다<br/>
<br/>
front.sh내용<br/>
------------------------------------------------<br/>
git clone https://github.com/yevgnenll/front.git<br/>
rm -r html/front<br/>
mv front html/front<br/>

[구현페이지 이동](http://yevgnenll.me/front/test.html)
